import { Component, OnInit } from '@angular/core';
import { GendisService } from './../../services/gendis.service';


@Component({
  selector: 'app-incidents',
  templateUrl: './incidents.component.html',
  styleUrls: ['./incidents.component.css']
})
export class IncidentsComponent {

  newComponents:any[] = [];

  constructor( private _gs: GendisService ) { 

    this._gs.getIncidents()
        .subscribe( (data:any) => {
          console.log(data);
          this.newComponents = data.components;
        });
  }
   ngOnInit() {
  }
  }

