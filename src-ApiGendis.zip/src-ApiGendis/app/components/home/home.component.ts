import { Component, OnInit } from '@angular/core';
import { GendisService } from '../../services/gendis.service';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  page:{} = {};
  status:{} = {};

  constructor( private _gs: GendisService ) { 

    this._gs.getOverall()
        .subscribe( (data:any) => {
          console.log(data);
          this.page = data.page;
          this.status = data.status;
        });
  }
  

  ngOnInit() {
    
  }
}
