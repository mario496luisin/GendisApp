import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { IncidentsComponent } from './components/incidents/incidents.component';


export const ROUTES: Routes = [
     { path: 'home', component: HomeComponent },
     { path: 'incidents', component: IncidentsComponent },
     { path: '**', pathMatch: 'full', redirectTo: 'home' }
 ];