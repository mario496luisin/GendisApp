export interface Page {
page:{
     id: string,
     name: string,
     url:string,
     updated_at:string,
}
}