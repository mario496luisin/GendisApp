export interface Incidents {
     components: {
          created_at: string,
          description: string,
          id:string,
          name:string,
          page_id:string,
          position:string,
          status:string,
          updated_at:string,
     },
     status: {
          description: string,
          indicator:string
     }
}