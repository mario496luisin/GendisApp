export interface Status {
     status:{
        description: string,
          indicator:string  
     }
          
     }