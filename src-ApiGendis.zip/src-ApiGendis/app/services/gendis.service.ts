import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class GendisService {

  constructor( private http:HttpClient ) { 
    console.log('El servicio esta preparado');
    
  }

  getOverall() {

    const apiUrl = 'https://bqlf8qjztdtr.statuspage.io/api/v2';

    return this.http.get(`${apiUrl}/status.json`);
      
  }

  getIncidents() {
    const apiUrl = 'https://bqlf8qjztdtr.statuspage.io/api/v2';
    
    return this.http.get(`${apiUrl}/components.json`)
  }

}